function addNumber() { 			
	var sum = 10 + 20;
	alert(sum);
}